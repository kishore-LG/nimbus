<%
    response.sendRedirect("login.jsp");
%>